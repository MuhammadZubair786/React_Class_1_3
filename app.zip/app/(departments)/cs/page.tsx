import Image from 'next/image'

export default function About() {
  return (
   <h1>
    CS DEPARTMENTS
   </h1>
  )
}
