import Image from 'next/image'

export default function Contact() {
  return (
   <h1>
   Contact Number Piaic :<i style={{backgroundColor:"red",color:"yellow"}}>02940902940</i>
   </h1>
  )
}
