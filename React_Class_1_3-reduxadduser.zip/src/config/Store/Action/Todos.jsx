const AddTodos = (user)=>{
    return((dispatch)=>{
        dispatch({
            type:"Add_Todo1",
            data:user
        })
    })
}

export {AddTodos}