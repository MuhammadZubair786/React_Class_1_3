import React, { useState } from "react";

function Form1(props){

    let [email,setemail]=useState("")
    let [Password,setPassword]=useState("")

    const submit = ()=>{
        if(email==""|| Password==""){
            alert("Enter Email & Password")
        }
        else{
            props.handlechg()
        }

    }


    return(
        <div style={{width:400,margin:"auto"}}>
        <h1>Form 1</h1>

        <input
        
        value={email}
        onChange={(e)=>setemail(e.target.value)}
        
        type="email" placeholder="enter email"  />
        <br />
        <input
        
        value={Password}
        onChange={(e)=>setPassword(e.target.value)}
        
        type="password" placeholder="enter password"  />
        <button onClick={()=>submit()} >Next</button>
        </div>
    )
}

export default Form1