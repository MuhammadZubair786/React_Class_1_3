import React, { useState } from "react";
import { Stepper, Step, StepLabel, Button, Typography } from "@mui/material";
import Form1 from "./Forms/Form1";

function getStepContent(activeStep,handlechg) {
  console.log(activeStep);

  switch (activeStep) {
    case 0:
      return <Form1 handlechg={handlechg}/>;
    case 1:
      return <h1>form 2</h1>;
    case 2:
      return <h1>form 3</h1>;
    default:
      return "invalid data";
  }
}

function StepperForm() {
  const [activestep1, setActiveStep] = useState(0);

  const steps = ["Eductaion information", "courses details", "cuntry details"];


  const handlechg =()=>{
    setActiveStep(activestep1+1)
  }

  return (
    <>
      <div className="">
        <Stepper activeStep={activestep1} alternativeLabel>
          {steps.map((v, i) => (
            <Step key={i}>
              <StepLabel>{v}</StepLabel>
            </Step>
          ))}
        </Stepper>

        {
        activestep1 == steps.length ? 
          "submit"
         :
         <>
          <Typography>{getStepContent(activestep1,handlechg)}</Typography>
        
       
          </>
        }

        
      </div>
    </>
  );
}

export default StepperForm;
