import React from "react";
import StepperForm from "./Components/StepperForm";

function App() {
  return (
    <>
      <h1>Stepper</h1>
      <StepperForm/>
    </>
  );
}
export default App;
